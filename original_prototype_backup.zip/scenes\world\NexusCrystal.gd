extends Node3D

@export var rotation_speed: float = 1.2
@export var bob_amplitude: float = 0.15
@export var bob_speed: float = 2.0

var base_y: float = 0.0
var time: float = 0.0

func _ready() -> void:
	base_y = position.y

func _process(delta: float) -> void:
	rotate_y(rotation_speed * delta)
	time += delta
	position.y = base_y + sin(time * bob_speed) * bob_amplitude
