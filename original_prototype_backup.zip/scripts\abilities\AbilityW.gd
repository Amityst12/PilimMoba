class_name AbilityW
extends Ability

@export var dash_distance: float = 8.5
@export var dash_duration: float = 0.18

func _init() -> void:
	id = "W"
	ability_name = "Phase Dash"
	description = "Dashes a short distance towards the target point or movement direction, quickly repositioning your champion."
	cooldown = 6.0
	mana_cost = 40.0
	cast_range = 10.0
	icon_color = Color(0.2, 0.9, 0.5)

func execute(caster: CharacterBody3D, target_pos: Vector3) -> void:
	var dir: Vector3 = target_pos - caster.global_position
	dir.y = 0.0
	if dir.length_squared() < 0.1:
		dir = -caster.global_transform.basis.z
	else:
		dir = dir.normalized()

	if caster.has_method("start_dash"):
		caster.start_dash(dir, dash_distance, dash_duration)
