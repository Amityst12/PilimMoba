class_name AbilityQ
extends Ability

@export var projectile_scene: PackedScene = preload("res://scenes/abilities/ProjectileQ.tscn")

func _init() -> void:
	id = "Q"
	ability_name = "Mystic Bolt"
	description = "Fires a swift mystic bolt in the target direction, dealing 80 magic damage to the first enemy hit."
	cooldown = 3.5
	mana_cost = 30.0
	cast_range = 22.0
	icon_color = Color(0.2, 0.7, 1.0)

func execute(caster: CharacterBody3D, target_pos: Vector3) -> void:
	if not projectile_scene:
		return

	var origin: Vector3 = caster.global_position + Vector3(0, 1.0, 0)
	var dir: Vector3 = (target_pos - caster.global_position)
	dir.y = 0.0
	if dir.length_squared() < 0.001:
		dir = -caster.global_transform.basis.z
	else:
		dir = dir.normalized()

	var projectile = projectile_scene.instantiate()
	projectile.direction = dir
	projectile.global_position = origin + dir * 1.2
	if caster.has_method("get_peer_id"):
		projectile.caster_peer_id = caster.get_peer_id()

	var entities_node = caster.get_tree().current_scene.get_node_or_null("Entities")
	if entities_node:
		entities_node.add_child(projectile, true)
	else:
		caster.get_parent().add_child(projectile, true)
