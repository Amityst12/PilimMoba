extends CanvasLayer

@onready var health_bar: ProgressBar = $ActionBar/VBox/BarsContainer/HealthBar
@onready var health_label: Label = $ActionBar/VBox/BarsContainer/HealthBar/HealthLabel
@onready var mana_bar: ProgressBar = $ActionBar/VBox/BarsContainer/ManaBar
@onready var mana_label: Label = $ActionBar/VBox/BarsContainer/ManaBar/ManaLabel

@onready var passive_rect: ColorRect = $ActionBar/VBox/SlotsContainer/PassiveSlot/VBox/IconBox/PassiveRect
@onready var passive_stack_label: Label = $ActionBar/VBox/SlotsContainer/PassiveSlot/VBox/IconBox/StackLabel
@onready var passive_name: Label = $ActionBar/VBox/SlotsContainer/PassiveSlot/VBox/PassiveName

@onready var slot_q: PanelContainer = $ActionBar/VBox/SlotsContainer/SlotQ
@onready var slot_w: PanelContainer = $ActionBar/VBox/SlotsContainer/SlotW
@onready var slot_e: PanelContainer = $ActionBar/VBox/SlotsContainer/SlotE
@onready var slot_r: PanelContainer = $ActionBar/VBox/SlotsContainer/SlotR

@onready var network_panel: PanelContainer = $LobbyMenu/NetworkPanel
@onready var host_btn: Button = $LobbyMenu/NetworkPanel/Margin/VBox/HostBtn
@onready var join_btn: Button = $LobbyMenu/NetworkPanel/Margin/VBox/JoinBtn
@onready var ip_edit: LineEdit = $LobbyMenu/NetworkPanel/Margin/VBox/IPEdit
@onready var status_label: Label = $LobbyMenu/NetworkPanel/Margin/VBox/StatusLabel
@onready var toggle_menu_btn: Button = $LobbyMenu/ToggleMenuBtn

var bound_player: Player

func _ready() -> void:
	# Keep lobby menu collapsed by default since game auto-starts
	if network_panel:
		network_panel.visible = false

	# Network button bindings
	host_btn.pressed.connect(_on_host_pressed)
	join_btn.pressed.connect(_on_join_pressed)
	toggle_menu_btn.pressed.connect(_on_toggle_menu_pressed)

	NetworkManager.status_message_updated.connect(_on_network_status_updated)
	NetworkManager.connection_succeeded.connect(func(): network_panel.visible = false)


func _on_host_pressed() -> void:
	var err: Error = NetworkManager.host_game(7777)
	if err == OK:
		network_panel.visible = false

func _on_join_pressed() -> void:
	var ip: String = ip_edit.text.strip_edges()
	if ip.is_empty():
		ip = "127.0.0.1"
	var err: Error = NetworkManager.join_game(ip, 7777)
	if err == OK:
		network_panel.visible = false

func _on_toggle_menu_pressed() -> void:
	network_panel.visible = !network_panel.visible

func _on_network_status_updated(msg: String) -> void:
	if status_label:
		status_label.text = msg

func bind_player(player: Player) -> void:
	bound_player = player
	player.stats_changed.connect(_on_stats_changed)

	if player.ability_holder:
		var holder: AbilityHolder = player.ability_holder
		holder.cooldown_updated.connect(_on_cooldown_updated)
		holder.passive_updated.connect(_on_passive_updated)

		# Setup slots
		slot_q.setup_ability(holder.get_ability("Q"), "Q")
		slot_w.setup_ability(holder.get_ability("W"), "W")
		slot_e.setup_ability(holder.get_ability("E"), "E")
		slot_r.setup_ability(holder.get_ability("R"), "R")

		var passive: Ability = holder.get_ability("Passive")
		if passive and passive_name:
			passive_name.text = passive.ability_name
			if passive_rect:
				passive_rect.color = passive.icon_color

	# Initialize values
	_on_stats_changed(player.current_health, player.max_health, player.current_mana, player.max_mana)
	_on_passive_updated("Arcane Flow", 0, 3, false)

func _on_stats_changed(hp: float, max_hp: float, mp: float, max_mp: float) -> void:
	if health_bar and health_label:
		health_bar.max_value = max_hp
		health_bar.value = hp
		health_label.text = "%d / %d" % [int(hp), int(max_hp)]

	if mana_bar and mana_label:
		mana_bar.max_value = max_mp
		mana_bar.value = mp
		mana_label.text = "%d / %d" % [int(mp), int(max_mp)]

func _on_cooldown_updated(slot: String, remaining: float, total: float) -> void:
	match slot.to_upper():
		"Q":
			slot_q.update_cooldown(remaining, total)
		"W":
			slot_w.update_cooldown(remaining, total)
		"E":
			slot_e.update_cooldown(remaining, total)
		"R":
			slot_r.update_cooldown(remaining, total)

func _on_passive_updated(desc: String, stacks: int, max_stacks: int, is_active: bool) -> void:
	if passive_stack_label:
		if is_active:
			passive_stack_label.text = "ACTIVE!"
			passive_stack_label.modulate = Color(1.0, 0.9, 0.2)
		else:
			passive_stack_label.text = "%d / %d" % [stacks, max_stacks]
			passive_stack_label.modulate = Color(1, 1, 1)

	if passive_name:
		passive_name.text = desc
