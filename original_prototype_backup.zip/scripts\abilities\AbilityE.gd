class_name AbilityE
extends Ability

@export var aoe_scene: PackedScene = preload("res://scenes/abilities/GroundAoEE.tscn")

func _init() -> void:
	id = "E"
	ability_name = "Gravity Well"
	description = "Targets a ground area. After 0.7s, detonates dealing 110 damage and slowing enemies by 45% for 2.5s."
	cooldown = 7.0
	mana_cost = 50.0
	cast_range = 16.0
	icon_color = Color(1.0, 0.5, 0.1)

func execute(caster: CharacterBody3D, target_pos: Vector3) -> void:
	if not aoe_scene:
		return

	var spawn_pos: Vector3 = get_clamped_target(caster, target_pos)
	spawn_pos.y = 0.0

	var aoe_instance = aoe_scene.instantiate()
	aoe_instance.global_position = spawn_pos
	if caster.has_method("get_peer_id"):
		aoe_instance.caster_peer_id = caster.get_peer_id()

	var entities_node = caster.get_tree().current_scene.get_node_or_null("Entities")
	if entities_node:
		entities_node.add_child(aoe_instance, true)
	else:
		caster.get_parent().add_child(aoe_instance, true)
