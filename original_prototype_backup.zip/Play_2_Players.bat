@echo off
cd /d "%~dp0"
echo Starting Instance 1 (Host)...
start "" "Godot_v4.7.2-stable_win64.exe" --path .
timeout /t 2 /nobreak >nul
echo Starting Instance 2 (Client)...
start "" "Godot_v4.7.2-stable_win64.exe" --path .
