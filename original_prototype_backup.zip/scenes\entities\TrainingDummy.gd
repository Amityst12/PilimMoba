extends CharacterBody3D

@export var max_health: float = 1200.0
@export var damage_number_scene: PackedScene = preload("res://scenes/vfx/DamageNumber.tscn")

var current_health: float = 1200.0
var is_alive: bool = true
var peer_id: int = -999 # Target dummy has unique non-player peer_id

@onready var mesh_body: MeshInstance3D = $MeshBody
@onready var overhead_hp: ProgressBar = $SubViewport/Panel/HealthBar
@onready var sprite_hp: Sprite3D = $Sprite3D
@onready var sub_viewport: SubViewport = $SubViewport

func _ready() -> void:
	add_to_group("players")
	current_health = max_health
	if sprite_hp and sub_viewport:
		sprite_hp.texture = sub_viewport.get_texture()
	_update_hp_bar()

func get_peer_id() -> int:
	return peer_id

func take_damage(amount: float, _attacker_id: int) -> void:
	if not is_alive:
		return

	current_health = max(0.0, current_health - amount)
	_update_hp_bar()
	_spawn_damage_number("-%d" % int(amount), Color(1.0, 0.3, 0.2), amount >= 200.0)
	_flash_hit()

	if current_health <= 0.0:
		die()

func apply_slow(percentage: float, _duration: float) -> void:
	if not is_alive:
		return
	_spawn_damage_number("SLOWED %d%%" % int(percentage * 100), Color(0.2, 0.8, 1.0), false)

func _spawn_damage_number(text: String, color: Color, is_crit: bool) -> void:
	if not damage_number_scene:
		return
	var dmg_node = damage_number_scene.instantiate()
	dmg_node.position = global_position + Vector3(0, 2.0, 0)
	get_parent().add_child(dmg_node)
	dmg_node.setup(text, color, is_crit)

func _flash_hit() -> void:
	if not mesh_body:
		return
	var mat: StandardMaterial3D = mesh_body.get_active_material(0)
	if mat:
		var orig_color: Color = mat.albedo_color
		mat.albedo_color = Color(1.0, 1.0, 1.0)
		var tween: Tween = create_tween()
		tween.tween_property(mat, "albedo_color", orig_color, 0.15)

func _update_hp_bar() -> void:
	if overhead_hp:
		overhead_hp.max_value = max_health
		overhead_hp.value = current_health

func die() -> void:
	is_alive = false
	visible = false
	_spawn_damage_number("DESTROYED!", Color(1.0, 0.8, 0.1), true)
	await get_tree().create_timer(3.0).timeout
	respawn()

func respawn() -> void:
	current_health = max_health
	is_alive = true
	visible = true
	_update_hp_bar()
	_spawn_damage_number("RESPAWNED", Color(0.2, 1.0, 0.4), false)
