extends Area3D

@export var speed: float = 24.0
@export var damage: float = 80.0
@export var max_lifetime: float = 1.5

var direction: Vector3 = Vector3.FORWARD
var caster_peer_id: int = 1
var lifetime: float = 0.0

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	# Face the flight direction
	if direction.length_squared() > 0.001:
		look_at(global_position + direction, Vector3.UP)

func _physics_process(delta: float) -> void:
	if not multiplayer.is_server():
		return

	global_position += direction * speed * delta
	lifetime += delta
	if lifetime >= max_lifetime:
		queue_free()

func _on_body_entered(body: Node3D) -> void:
	if not multiplayer.is_server():
		return

	if body.is_in_group("players"):
		# Prevent hitting the caster
		if body.has_method("get_peer_id") and body.get_peer_id() == caster_peer_id:
			return

		if body.has_method("take_damage"):
			body.take_damage(damage, caster_peer_id)
		queue_free()
