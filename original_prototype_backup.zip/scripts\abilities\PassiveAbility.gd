class_name PassiveAbility
extends Ability

@export var max_stacks: int = 3
@export var speed_buff_percentage: float = 0.40
@export var speed_buff_duration: float = 3.0
@export var hp_regen_per_sec: float = 3.0
@export var mana_regen_per_sec: float = 4.0

var current_stacks: int = 0
var buff_timer: float = 0.0

func _init() -> void:
	id = "Passive"
	ability_name = "Arcane Flow"
	description = "Every 3rd ability cast triggers Arcane Flow, granting +40% Movement Speed for 3 seconds. Continuously regenerates HP and Mana."
	cooldown = 0.0
	mana_cost = 0.0
	cast_range = 0.0
	icon_color = Color(0.1, 0.8, 0.9)

func on_ability_cast(caster: CharacterBody3D, _slot: String) -> void:
	current_stacks += 1
	if current_stacks >= max_stacks:
		current_stacks = 0
		trigger_passive_buff(caster)
	else:
		if caster.has_method("notify_passive_state"):
			caster.notify_passive_state("Arcane Flow", current_stacks, max_stacks, false)

func trigger_passive_buff(caster: CharacterBody3D) -> void:
	buff_timer = speed_buff_duration
	if caster.has_method("apply_speed_buff"):
		caster.apply_speed_buff(speed_buff_percentage, speed_buff_duration)
	if caster.has_method("notify_passive_state"):
		caster.notify_passive_state("Arcane Flow (ACTIVE!)", max_stacks, max_stacks, true)

func update_passive(caster: CharacterBody3D, delta: float) -> void:
	# Passive HP & Mana regeneration
	if caster.multiplayer.is_server():
		if caster.has_method("heal"):
			caster.heal(hp_regen_per_sec * delta)
		if caster.has_method("restore_mana"):
			caster.restore_mana(mana_regen_per_sec * delta)

	if buff_timer > 0.0:
		buff_timer -= delta
		if buff_timer <= 0.0:
			buff_timer = 0.0
			if caster.has_method("notify_passive_state"):
				caster.notify_passive_state("Arcane Flow", current_stacks, max_stacks, false)
