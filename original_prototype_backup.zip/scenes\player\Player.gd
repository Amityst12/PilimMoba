class_name Player
extends CharacterBody3D

signal stats_changed(current_hp: float, max_hp: float, current_mp: float, max_mp: float)
signal player_died()
signal player_respawned()

@export var base_speed: float = 7.5
@export var turn_speed: float = 14.0
@export var max_health: float = 600.0
@export var max_mana: float = 250.0
@export var click_marker_scene: PackedScene = preload("res://scenes/vfx/ClickMarker.tscn")
@export var damage_number_scene: PackedScene = preload("res://scenes/vfx/DamageNumber.tscn")

@export var peer_id: int = 1:
	set(val):
		peer_id = val
		_update_authority_and_visuals()

@export var team: int = 1:
	set(val):
		team = val
		_update_team_visuals()

@export var current_health: float = 600.0:
	set(val):
		current_health = clamp(val, 0.0, max_health)
		_on_stats_updated()

@export var current_mana: float = 250.0:
	set(val):
		current_mana = clamp(val, 0.0, max_mana)
		_on_stats_updated()

# Movement state
var current_speed: float = 7.5
var is_dashing: bool = false
var dash_direction: Vector3 = Vector3.FORWARD
var dash_speed: float = 0.0
var dash_timer: float = 0.0

# Buff / Slow tracking
var speed_modifier: float = 1.0
var speed_modifier_timer: float = 0.0

# Respawn
var is_alive: bool = true
var spawn_position: Vector3 = Vector3.ZERO

@onready var nav_agent: NavigationAgent3D = $NavigationAgent3D
@onready var ability_holder: AbilityHolder = $AbilityHolder
@onready var overhead_ui: Node3D = $OverheadUI
@onready var mesh_instance: MeshInstance3D = $MeshInstance3D
@onready var camera: Camera3D = $PlayerCamera

func _ready() -> void:
	if name.is_valid_int():
		peer_id = name.to_int()

	add_to_group("players")
	spawn_position = global_position
	current_health = max_health
	current_mana = max_mana
	current_speed = base_speed
	_update_authority_and_visuals()

	# Configure navigation agent
	nav_agent.path_desired_distance = 0.5
	nav_agent.target_desired_distance = 0.5

	# Connect local HUD if this is the local player
	if is_local_player():
		call_deferred("_connect_to_hud")

func is_local_player() -> bool:
	return peer_id == multiplayer.get_unique_id()

func _update_authority_and_visuals() -> void:
	if not is_inside_tree():
		return
	if is_local_player():
		call_deferred("_connect_to_hud")
	if camera:
		camera.current = is_local_player()
	if overhead_ui and overhead_ui.has_method("update_name"):
		var role: String = "Host" if peer_id == 1 else "Player %d" % peer_id
		overhead_ui.update_name(role, team)
	_update_team_visuals()


func _update_team_visuals() -> void:
	if not mesh_instance:
		return
	var mat: StandardMaterial3D = mesh_instance.get_active_material(0)
	if not mat:
		mat = StandardMaterial3D.new()
		mesh_instance.set_surface_override_material(0, mat)
	else:
		mat = mat.duplicate()
		mesh_instance.set_surface_override_material(0, mat)

	if team == 1:
		mat.albedo_color = Color(0.2, 0.5, 0.95) # Team Blue
		mat.emission_enabled = true
		mat.emission = Color(0.1, 0.3, 0.7)
		mat.emission_energy_multiplier = 0.5
	else:
		mat.albedo_color = Color(0.95, 0.25, 0.25) # Team Red
		mat.emission_enabled = true
		mat.emission = Color(0.7, 0.1, 0.1)
		mat.emission_energy_multiplier = 0.5

func _connect_to_hud() -> void:
	var hud: Node = get_tree().current_scene.get_node_or_null("HUD")
	if hud and hud.has_method("bind_player"):
		hud.bind_player(self)

func _unhandled_input(event: InputEvent) -> void:
	if not is_local_player() or not is_alive:
		return

	# Right click for movement
	if event.is_action_pressed("click_move"):
		var mouse_ground: Vector3 = get_mouse_ground_position()
		_spawn_click_marker(mouse_ground)
		request_move.rpc_id(1, mouse_ground)
		get_viewport().set_input_as_handled()


	# Ability Hotkeys (Q, W, E, R)
	elif event.is_action_pressed("ability_q"):
		_try_cast_slot("Q")
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("ability_w"):
		_try_cast_slot("W")
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("ability_e"):
		_try_cast_slot("E")
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("ability_r"):
		_try_cast_slot("R")
		get_viewport().set_input_as_handled()

func _try_cast_slot(slot: String) -> void:
	if not ability_holder or not ability_holder.can_cast(slot):
		return
	var mouse_pos: Vector3 = get_mouse_ground_position()
	request_cast_ability.rpc_id(1, slot, mouse_pos)

func get_mouse_ground_position() -> Vector3:
	var viewport: Viewport = get_viewport()
	var cam: Camera3D = viewport.get_camera_3d()
	if not cam:
		return global_position

	var mouse_pos: Vector2 = viewport.get_mouse_position()
	var ray_origin: Vector3 = cam.project_ray_origin(mouse_pos)
	var ray_dir: Vector3 = cam.project_ray_normal(mouse_pos)

	var ground_plane: Plane = Plane(Vector3.UP, 0.0)
	var hit: Variant = ground_plane.intersects_ray(ray_origin, ray_dir)
	if hit != null:
		return hit as Vector3
	return ray_origin + ray_dir * 25.0

func _physics_process(delta: float) -> void:
	# Server handles physics & movement
	if multiplayer.is_server():
		_process_server_physics(delta)

	# Client & Server: Handle speed modifiers decay
	if speed_modifier_timer > 0.0:
		speed_modifier_timer -= delta
		if speed_modifier_timer <= 0.0:
			speed_modifier = 1.0
			current_speed = base_speed

func _process_server_physics(delta: float) -> void:
	if not is_alive:
		velocity = Vector3.ZERO
		move_and_slide()
		return

	# Handle Dash
	if is_dashing:
		dash_timer -= delta
		velocity = dash_direction * dash_speed
		move_and_slide()
		if dash_timer <= 0.0:
			is_dashing = false
			velocity = Vector3.ZERO
		return

	# Navigation Path Movement
	if not nav_agent.is_navigation_finished():
		var next_path_pos: Vector3 = nav_agent.get_next_path_position()
		var move_vector: Vector3 = next_path_pos - global_position
		move_vector.y = 0.0

		if move_vector.length() > 0.2:
			var dir: Vector3 = move_vector.normalized()
			velocity = dir * current_speed

			# Smooth rotation towards movement direction
			var target_rot_y: float = atan2(-dir.x, -dir.z)
			rotation.y = lerp_angle(rotation.y, target_rot_y, turn_speed * delta)
		else:
			velocity = velocity.move_toward(Vector3.ZERO, 30.0 * delta)
	else:
		velocity = velocity.move_toward(Vector3.ZERO, 30.0 * delta)

	move_and_slide()

# Server RPC: Receive move destination from client
@rpc("any_peer", "call_local", "reliable")
func request_move(target_pos: Vector3) -> void:
	if not multiplayer.is_server() or not is_alive:
		return
	is_dashing = false
	target_pos.y = 0.0
	nav_agent.target_position = target_pos

# Server RPC: Receive ability cast request from client
@rpc("any_peer", "call_local", "reliable")
func request_cast_ability(slot: String, target_pos: Vector3) -> void:
	if not multiplayer.is_server() or not is_alive:
		return
	var sender_id: int = multiplayer.get_remote_sender_id()
	# Check authority (sender must own this champion, or if local host sender_id is 0/1)
	if sender_id != 0 and sender_id != peer_id:
		return

	if ability_holder and ability_holder.execute_cast(slot, target_pos):
		# Sync cooldown and cast notification to all peers for visuals/audio
		sync_ability_cast.rpc(slot)

@rpc("call_local", "reliable")
func sync_ability_cast(slot: String) -> void:
	if ability_holder:
		ability_holder.start_cooldown(slot)

func _spawn_click_marker(pos: Vector3) -> void:
	if not click_marker_scene:
		return
	var marker: Node3D = click_marker_scene.instantiate() as Node3D
	marker.position = pos
	get_tree().current_scene.add_child(marker)

func _spawn_combat_text(text_val: String, color: Color = Color(1.0, 0.3, 0.3), is_crit: bool = false) -> void:
	if not damage_number_scene:
		return
	var dmg_node = damage_number_scene.instantiate()
	dmg_node.position = global_position + Vector3(0, 2.2, 0)
	get_tree().current_scene.add_child(dmg_node)
	dmg_node.setup(text_val, color, is_crit)

@rpc("call_local", "reliable")
func rpc_spawn_damage_text(text_val: String, color: Color, is_crit: bool) -> void:
	_spawn_combat_text(text_val, color, is_crit)

# Combat Methods
func take_damage(amount: float, _attacker_id: int) -> void:
	if not is_alive:
		return
	if multiplayer.is_server():
		current_health -= amount
		rpc_spawn_damage_text.rpc("-%d" % int(amount), Color(1.0, 0.25, 0.25), amount >= 200.0)
		if current_health <= 0.0:
			die()

func heal(amount: float) -> void:
	if not multiplayer.is_server() or not is_alive:
		return
	current_health += amount

func consume_mana(amount: float) -> bool:
	if current_mana >= amount:
		current_mana -= amount
		return true
	return false

func restore_mana(amount: float) -> void:
	if not multiplayer.is_server() or not is_alive:
		return
	current_mana += amount

func get_current_mana() -> float:
	return current_mana

func get_peer_id() -> int:
	return peer_id

func apply_speed_buff(percentage: float, duration: float) -> void:
	speed_modifier = 1.0 + percentage
	speed_modifier_timer = duration
	current_speed = base_speed * speed_modifier
	if multiplayer.is_server():
		rpc_spawn_damage_text.rpc("SPEED UP!", Color(0.2, 1.0, 0.4), false)

func apply_slow(percentage: float, duration: float) -> void:
	speed_modifier = max(0.3, 1.0 - percentage)
	speed_modifier_timer = duration
	current_speed = base_speed * speed_modifier
	if multiplayer.is_server():
		rpc_spawn_damage_text.rpc("SLOWED %d%%" % int(percentage * 100), Color(0.2, 0.8, 1.0), false)


func start_dash(dir: Vector3, distance: float, duration: float) -> void:
	if not multiplayer.is_server():
		return
	is_dashing = true
	dash_direction = dir.normalized()
	dash_timer = duration
	dash_speed = distance / duration
	var target_rot_y: float = atan2(-dash_direction.x, -dash_direction.z)
	rotation.y = target_rot_y
	nav_agent.target_position = global_position # Cancel pathing


func notify_passive_state(desc: String, stacks: int, max_st: int, active: bool) -> void:
	if ability_holder:
		ability_holder.passive_updated.emit(desc, stacks, max_st, active)

func die() -> void:
	is_alive = false
	current_health = 0.0
	velocity = Vector3.ZERO
	player_died.emit()
	visible = false
	# Respawn after 4 seconds
	await get_tree().create_timer(4.0).timeout
	respawn()

func respawn() -> void:
	global_position = spawn_position
	current_health = max_health
	current_mana = max_mana
	is_alive = true
	visible = true
	player_respawned.emit()

func _on_stats_updated() -> void:
	stats_changed.emit(current_health, max_health, current_mana, max_mana)
	if overhead_ui and overhead_ui.has_method("update_health"):
		overhead_ui.update_health(current_health, max_health)
		overhead_ui.update_mana(current_mana, max_mana)
