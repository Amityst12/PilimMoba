# PilimMoba - Godot 4 Multiplayer MOBA Prototype

A lightweight, modular, top-down multiplayer MOBA prototype built in **Godot 4.x** with typed GDScript, server-authoritative ENet networking, click-to-move navigation, and an extensible ability system.

---

## 🎮 Controls

| Action | Input | Description |
| :--- | :--- | :--- |
| **Move** | `Right Click` | Pathfinds and smoothly moves champion to target point |
| **Passive** | *Automatic* | **Arcane Flow**: Every 3rd ability cast grants +40% Move Speed for 3s; passive HP/MP regen |
| **Q (Skillshot)** | `Q` | **Mystic Bolt**: Fires a fast skillshot projectile toward mouse cursor (80 dmg) |
| **W (Dash)** | `W` | **Phase Dash**: Quickly dashes in cursor/facing direction (8.5m) |
| **E (Ground AoE)** | `E` | **Gravity Well**: Spawns delayed circle at cursor (0.7s) dealing 110 dmg & 45% slow |
| **R (Ultimate)** | `R` | **Obliteration Beam**: Massive piercing directional beam dealing 240 heavy damage |
| **Network Menu** | Top-Left Button | Toggle Host/Join dialog |

---

## 📂 Project Architecture

```
PilimMoba/
├── project.godot                     # Project settings, input mappings, autoloads
├── scripts/
│   ├── core/
│   │   ├── Ability.gd               # Base Resource class for all abilities
│   │   └── AbilityHolder.gd         # Component managing champion ability slots & cooldowns
│   ├── networking/
│   │   └── NetworkManager.gd        # Autoload managing ENet peer, connections & player list
│   └── abilities/
│       ├── PassiveAbility.gd        # Arcane Flow passive logic
│       ├── AbilityQ.gd              # Q Skillshot ability definition
│       ├── AbilityW.gd              # W Dash ability definition
│       ├── AbilityE.gd              # E AoE delayed circle ability definition
│       └── AbilityR.gd              # R Ultimate beam ability definition
├── scenes/
│   ├── main/
│   │   ├── Main.tscn                # Main scene (Arena, Spawners, HUD)
│   │   └── Main.gd                  # Orchestrates player spawning and synchronization
│   ├── world/
│   │   └── Arena.tscn               # 3D MOBA arena with NavigationRegion3D and pillars
│   ├── player/
│   │   ├── Player.tscn              # CharacterBody3D capsule champion
│   │   ├── Player.gd                # Movement, authority, combat, and RPCs
│   │   ├── PlayerCamera.gd          # Top-down isometric follow camera
│   │   ├── OverheadUI.tscn          # Floating health/mana bar and nameplate
│   │   └── OverheadUI.gd
│   ├── abilities/
│   │   ├── ProjectileQ.tscn         # Replicated skillshot orb (Area3D + SphereMesh)
│   │   ├── ProjectileQ.gd
│   │   ├── GroundAoEE.tscn          # Replicated ground AoE indicator (Area3D + CylinderMesh)
│   │   ├── GroundAoEE.gd
│   │   ├── UltimateBeamR.tscn       # Replicated piercing beam (Area3D + BoxMesh)
│   │   └── UltimateBeamR.gd
│   └── ui/
│       ├── HUD.tscn                 # Bottom-center MOBA action bar + Network lobby
│       ├── HUD.gd                   # Action bar updates, cooldown sweeps, HP/Mana display
│       ├── AbilitySlot.tscn         # Individual Q/W/E/R ability slot widget
│       └── AbilitySlot.gd
```

---

## 🌐 Networking Architecture

1. **Host as Authoritative Server (`peer_id == 1`)**:
   - The host maintains the simulation state (player positions, collision, health/mana, cooldown validation, spell entity spawning).
2. **Client Inputs via RPC**:
   - Right-click movement requests are sent via `@rpc("any_peer", "call_local", "reliable") func request_move(target_pos)`.
   - Ability cast requests are sent via `@rpc("any_peer", "call_local", "reliable") func request_cast_ability(slot, target_pos)`.
3. **Replication via Godot 4 Nodes**:
   - **`MultiplayerSpawner`**: Automatically synchronizes instantiation of player champions (`Player.tscn`) and spell projectiles/effects (`ProjectileQ.tscn`, `GroundAoEE.tscn`, `UltimateBeamR.tscn`).
   - **`MultiplayerSynchronizer`**: Continuously replicates `position`, `rotation`, `current_health`, and `current_mana`.

---

## ⚡ How to Add a New Ability

1. Create a script extending `Ability.gd` (e.g. `scripts/abilities/AbilityHeal.gd`):
   ```gdscript
   class_name AbilityHeal
   extends Ability

   func _init() -> void:
       id = "W"
       ability_name = "Restoration"
       cooldown = 8.0
       mana_cost = 45.0
       icon_color = Color(0.2, 0.9, 0.3)

   func execute(caster: CharacterBody3D, target_pos: Vector3) -> void:
       if caster.has_method("heal"):
           caster.heal(120.0)
   ```
2. In `AbilityHolder.gd` (or in the Inspector on `Player.tscn`), assign your custom ability resource to any slot (`ability_q`, `ability_w`, `ability_e`, `ability_r`).
3. The HUD and networking will automatically detect and bind the new ability name, cooldown, mana cost, and color!

---

## 🚀 How to Run & Test Multiplayer

### In the Godot 4 Editor:
1. Open Godot 4 and import/open the project in `PilimMoba`.
2. Under **Debug** in the top menu, click **Run Multiple Instances** -> Select **2 Instances**.
3. Press **F5** (Run Project).
4. On **Window 1**: Click **Host Game (Port 7777)**. A Blue champion will spawn at the Blue base (`-14, 0, 0`).
5. On **Window 2**: Keep `127.0.0.1` and click **Join Game**. A Red champion will spawn at the Red base (`14, 0, 0`).
6. Right-click to move around the arena. Press **Q**, **W**, **E**, and **R** to fire abilities at each other and test damage, slow, dash, and cooldown timers!
