extends Node

signal player_connected(peer_id: int, player_info: Dictionary)
signal player_disconnected(peer_id: int)
signal server_disconnected()
signal connection_succeeded()
signal connection_failed()
signal status_message_updated(message: String)

const DEFAULT_PORT: int = 7777
const MAX_CLIENTS: int = 10

var peer: ENetMultiplayerPeer
var players: Dictionary = {} # peer_id -> Dictionary
var local_player_info: Dictionary = {
	"name": "Champion",
	"team": 1
}

func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)

func host_game(port: int = DEFAULT_PORT) -> Error:
	peer = ENetMultiplayerPeer.new()
	var error: Error = peer.create_server(port, MAX_CLIENTS)
	if error != OK:
		var err_msg: String = "Failed to host on port %d: %s" % [port, error_string(error)]
		status_message_updated.emit(err_msg)
		return error

	multiplayer.multiplayer_peer = peer
	local_player_info["team"] = 1 # Host is team 1 (Blue)
	players[1] = local_player_info
	player_connected.emit(1, local_player_info)
	status_message_updated.emit("Hosting server on port %d. Waiting for players..." % port)
	return OK

func join_game(ip: String = "127.0.0.1", port: int = DEFAULT_PORT) -> Error:
	if ip.strip_edges().is_empty():
		ip = "127.0.0.1"
	peer = ENetMultiplayerPeer.new()
	var error: Error = peer.create_client(ip, port)
	if error != OK:
		var err_msg: String = "Failed to initiate connection to %s:%d: %s" % [ip, port, error_string(error)]
		status_message_updated.emit(err_msg)
		return error

	multiplayer.multiplayer_peer = peer
	status_message_updated.emit("Connecting to %s:%d..." % [ip, port])
	return OK

func disconnect_game() -> void:
	if multiplayer.multiplayer_peer:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null
	players.clear()
	status_message_updated.emit("Disconnected from game.")

func _on_peer_connected(id: int) -> void:
	status_message_updated.emit("Peer connected: %d" % id)

func _on_peer_disconnected(id: int) -> void:
	status_message_updated.emit("Peer disconnected: %d" % id)
	if players.has(id):
		players.erase(id)
	player_disconnected.emit(id)

func _on_connected_to_server() -> void:
	var my_id: int = multiplayer.get_unique_id()
	status_message_updated.emit("Successfully connected as Peer %d!" % my_id)
	# Assign team 2 (Red) for joiners
	local_player_info["team"] = 2
	register_player.rpc_id(1, local_player_info)
	connection_succeeded.emit()

func _on_connection_failed() -> void:
	multiplayer.multiplayer_peer = null
	status_message_updated.emit("Connection failed!")
	connection_failed.emit()

func _on_server_disconnected() -> void:
	multiplayer.multiplayer_peer = null
	players.clear()
	status_message_updated.emit("Server shut down.")
	server_disconnected.emit()

@rpc("any_peer", "reliable")
func register_player(info: Dictionary) -> void:
	var sender_id: int = multiplayer.get_remote_sender_id()
	players[sender_id] = info
	player_connected.emit(sender_id, info)
	# Sync full players dictionary to newly connected peer
	sync_player_list.rpc_id(sender_id, players)
	# Notify all other clients of this new player
	sync_single_player.rpc(sender_id, info)

@rpc("authority", "reliable")
func sync_player_list(all_players: Dictionary) -> void:
	players = all_players
	for id: int in players:
		player_connected.emit(id, players[id])

@rpc("authority", "reliable")
func sync_single_player(id: int, info: Dictionary) -> void:
	players[id] = info
	player_connected.emit(id, info)
