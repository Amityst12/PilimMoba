extends Area3D

@export var delay: float = 0.7
@export var radius: float = 3.5
@export var damage: float = 110.0
@export var slow_percentage: float = 0.45
@export var slow_duration: float = 2.5

@onready var indicator_mesh: MeshInstance3D = $IndicatorMesh
@onready var collision_shape: CollisionShape3D = $CollisionShape3D

var caster_peer_id: int = 1
var timer: float = 0.0
var has_detonated: bool = false

func _ready() -> void:
	if indicator_mesh and indicator_mesh.get_active_material(0):
		var mat: StandardMaterial3D = indicator_mesh.get_active_material(0).duplicate()
		indicator_mesh.set_surface_override_material(0, mat)

	# Match collision shape to radius
	if collision_shape.shape is CylinderShape3D:
		var cyl: CylinderShape3D = collision_shape.shape
		cyl.radius = radius
		cyl.height = 1.0


func _physics_process(delta: float) -> void:
	if has_detonated:
		return

	timer += delta
	# Visual pulsing / telegraph effect
	if indicator_mesh and indicator_mesh.get_active_material(0):
		var mat: StandardMaterial3D = indicator_mesh.get_active_material(0)
		var progress: float = clamp(timer / delay, 0.0, 1.0)
		mat.albedo_color.a = lerp(0.3, 0.8, progress)

	if timer >= delay:
		detonate()

func detonate() -> void:
	has_detonated = true

	# Flash brightly on detonation
	if indicator_mesh and indicator_mesh.get_active_material(0):
		var mat: StandardMaterial3D = indicator_mesh.get_active_material(0)
		mat.albedo_color = Color(1.0, 0.9, 0.2, 0.9)
		mat.emission_energy_multiplier = 5.0

	# Damage and slow targets on server
	if multiplayer.is_server():
		var overlapping_bodies: Array[Node3D] = get_overlapping_bodies()
		for body: Node3D in overlapping_bodies:
			if body.is_in_group("players"):
				if body.has_method("get_peer_id") and body.get_peer_id() == caster_peer_id:
					continue
				if body.has_method("take_damage"):
					body.take_damage(damage, caster_peer_id)
				if body.has_method("apply_slow"):
					body.apply_slow(slow_percentage, slow_duration)

	# Clean up after brief flash
	await get_tree().create_timer(0.2).timeout
	queue_free()
