extends Camera3D

@export var target_offset: Vector3 = Vector3(0, 16, 11)
@export var smooth_speed: float = 12.0

@onready var player: CharacterBody3D = get_parent() as CharacterBody3D

func _ready() -> void:
	# Ensure camera does not rotate with the character mesh
	set_as_top_level(true)
	rotation_degrees = Vector3(-55, 0, 0)

	# Only the local player's camera should be active
	if player and player.has_method("is_local_player"):
		current = player.is_local_player()
		global_position = player.global_position + target_offset

func _process(delta: float) -> void:
	if not current:
		if is_instance_valid(player) and player.has_method("is_local_player") and player.is_local_player():
			current = true
			global_position = player.global_position + target_offset
		else:
			return

	if not is_instance_valid(player):
		return

	var target_pos: Vector3 = player.global_position + target_offset
	global_position = global_position.lerp(target_pos, smooth_speed * delta)
