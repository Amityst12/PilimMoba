class_name AbilityR
extends Ability

@export var beam_scene: PackedScene = preload("res://scenes/abilities/UltimateBeamR.tscn")

func _init() -> void:
	id = "R"
	ability_name = "Obliteration Beam"
	description = "Channels a massive piercing beam in the target direction, dealing 240 heavy damage."
	cooldown = 14.0
	mana_cost = 80.0
	cast_range = 28.0
	icon_color = Color(1.0, 0.2, 0.4)

func execute(caster: CharacterBody3D, target_pos: Vector3) -> void:
	if not beam_scene:
		return

	var origin: Vector3 = caster.global_position
	origin.y = 0.0
	var dir: Vector3 = target_pos - origin
	dir.y = 0.0
	if dir.length_squared() < 0.01:
		dir = -caster.global_transform.basis.z
	else:
		dir = dir.normalized()

	var beam = beam_scene.instantiate()
	beam.global_position = origin
	if caster.has_method("get_peer_id"):
		beam.caster_peer_id = caster.get_peer_id()

	# Rotate towards target direction
	beam.look_at(origin + dir, Vector3.UP)

	var entities_node = caster.get_tree().current_scene.get_node_or_null("Entities")
	if entities_node:
		entities_node.add_child(beam, true)
	else:
		caster.get_parent().add_child(beam, true)
