extends PanelContainer

@export var slot_key: String = "Q"

@onready var icon_rect: ColorRect = $MarginContainer/VBox/IconBox/IconRect
@onready var cd_overlay: ColorRect = $MarginContainer/VBox/IconBox/CooldownOverlay
@onready var cd_label: Label = $MarginContainer/VBox/IconBox/CooldownLabel
@onready var key_badge: Label = $MarginContainer/VBox/IconBox/KeyBadge
@onready var mana_label: Label = $MarginContainer/VBox/IconBox/ManaLabel
@onready var name_label: Label = $MarginContainer/VBox/NameLabel

var current_ability: Ability

func _ready() -> void:
	if key_badge:
		key_badge.text = slot_key
	if cd_overlay:
		cd_overlay.visible = false
	if cd_label:
		cd_label.visible = false

func setup_ability(ability: Ability, key: String = "") -> void:
	current_ability = ability
	if not key.is_empty():
		slot_key = key
		if key_badge:
			key_badge.text = slot_key

	if ability:
		if name_label:
			name_label.text = ability.ability_name
		if icon_rect:
			icon_rect.color = ability.icon_color
		if mana_label:
			mana_label.text = "%d" % int(ability.mana_cost) if ability.mana_cost > 0 else ""
	else:
		if name_label:
			name_label.text = "Locked"
		if mana_label:
			mana_label.text = ""

func update_cooldown(remaining: float, total: float) -> void:
	if not cd_overlay or not cd_label:
		return

	if remaining > 0.05 and total > 0.0:
		cd_overlay.visible = true
		cd_label.visible = true
		var ratio: float = clamp(remaining / total, 0.0, 1.0)
		# Shrink cooldown overlay height from top down
		var full_height: float = icon_rect.size.y if icon_rect else 56.0
		cd_overlay.size.y = full_height * ratio

		if remaining >= 1.0:
			cd_label.text = "%.1f" % remaining
		else:
			cd_label.text = "%.1f" % remaining
	else:
		cd_overlay.visible = false
		cd_label.visible = false
