@echo off
cd /d "%~dp0"
echo Starting MOBA Game...
start "" "Godot_v4.7.2-stable_win64.exe" --path .
