extends Area3D

@export var damage: float = 240.0
@export var beam_width: float = 3.5
@export var beam_length: float = 28.0
@export var duration: float = 0.45

@onready var beam_mesh: MeshInstance3D = $BeamMesh
@onready var collision_shape: CollisionShape3D = $CollisionShape3D

var caster_peer_id: int = 1
var timer: float = 0.0
var damaged_bodies: Dictionary = {} # peer_id -> bool

func _ready() -> void:
	if beam_mesh and beam_mesh.get_active_material(0):
		var mat: StandardMaterial3D = beam_mesh.get_active_material(0).duplicate()
		beam_mesh.set_surface_override_material(0, mat)

	# Damage overlapping bodies immediately on spawn
	if multiplayer.is_server():
		# Wait 1 frame for physics to overlap
		await get_tree().physics_frame
		apply_beam_damage()


func _physics_process(delta: float) -> void:
	timer += delta

	# Fade out beam visual
	if beam_mesh and beam_mesh.get_active_material(0):
		var mat: StandardMaterial3D = beam_mesh.get_active_material(0)
		var fade: float = clamp(1.0 - (timer / duration), 0.0, 1.0)
		mat.albedo_color.a = fade * 0.9
		mat.emission_energy_multiplier = fade * 4.0

	# Apply damage continuously to any new bodies entering during beam active time
	if multiplayer.is_server():
		apply_beam_damage()

	if timer >= duration:
		queue_free()

func apply_beam_damage() -> void:
	var bodies: Array[Node3D] = get_overlapping_bodies()
	for body: Node3D in bodies:
		if body.is_in_group("players"):
			var body_id: int = body.get_instance_id()
			if damaged_bodies.has(body_id):
				continue

			if body.has_method("get_peer_id") and body.get_peer_id() == caster_peer_id:
				continue

			damaged_bodies[body_id] = true
			if body.has_method("take_damage"):
				body.take_damage(damage, caster_peer_id)
