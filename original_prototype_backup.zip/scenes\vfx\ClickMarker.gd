extends Node3D

@onready var mesh_instance: MeshInstance3D = $MeshInstance3D

func _ready() -> void:
	# Duplicate material so tweening alpha is unique
	if mesh_instance and mesh_instance.get_active_material(0):
		var mat: StandardMaterial3D = mesh_instance.get_active_material(0).duplicate()
		mesh_instance.set_surface_override_material(0, mat)

		var tween: Tween = create_tween().set_parallel(true)
		# Expand scale slightly
		scale = Vector3(0.5, 0.5, 0.5)
		tween.tween_property(self, "scale", Vector3(1.3, 1.0, 1.3), 0.35).set_trans(Tween.TRANS_OUT).set_ease(Tween.EASE_OUT)
		# Fade out alpha
		tween.tween_property(mat, "albedo_color:a", 0.0, 0.35).set_trans(Tween.TRANS_IN).set_ease(Tween.EASE_IN)
		# Clean up after animation
		tween.chain().tween_callback(queue_free)
	else:
		await get_tree().create_timer(0.35).timeout
		queue_free()
