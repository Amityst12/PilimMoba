extends Node3D

@onready var name_label: Label = $SubViewport/Panel/VBoxContainer/NameLabel
@onready var health_bar: ProgressBar = $SubViewport/Panel/VBoxContainer/HealthBar
@onready var mana_bar: ProgressBar = $SubViewport/Panel/VBoxContainer/ManaBar
@onready var sub_viewport: SubViewport = $SubViewport
@onready var sprite: Sprite3D = $Sprite3D

func _ready() -> void:
	if sprite and sub_viewport:
		sprite.texture = sub_viewport.get_texture()


func update_name(player_name: String, team: int) -> void:
	if name_label:
		name_label.text = player_name
		name_label.modulate = Color(0.3, 0.7, 1.0) if team == 1 else Color(1.0, 0.3, 0.3)

func update_health(current: float, maximum: float) -> void:
	if health_bar:
		health_bar.max_value = maximum
		health_bar.value = current

func update_mana(current: float, maximum: float) -> void:
	if mana_bar:
		mana_bar.max_value = maximum
		mana_bar.value = current
