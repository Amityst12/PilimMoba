class_name Ability
extends Resource

@export var id: String = "Q"
@export var ability_name: String = "Generic Ability"
@export_multiline var description: String = ""
@export var cooldown: float = 4.0
@export var mana_cost: float = 25.0
@export var cast_range: float = 15.0
@export var icon_color: Color = Color(0.2, 0.6, 1.0)

# Check if caster has required state / mana to cast
func can_cast(caster: CharacterBody3D) -> bool:
	if caster.has_method("get_current_mana") and caster.get_current_mana() < mana_cost:
		return false
	if caster.has_method("is_alive") and not caster.is_alive():
		return false
	return true

# Server-authoritative execution
func execute(caster: CharacterBody3D, target_pos: Vector3) -> void:
	pass

# Helper to clamp cast target within max range
func get_clamped_target(caster: CharacterBody3D, target_pos: Vector3) -> Vector3:
	var origin: Vector3 = caster.global_position
	origin.y = 0.0
	var target: Vector3 = target_pos
	target.y = 0.0
	var diff: Vector3 = target - origin
	if diff.length() > cast_range:
		return origin + diff.normalized() * cast_range
	return target
