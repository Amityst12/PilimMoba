extends Node3D

@export var player_scene: PackedScene = preload("res://scenes/player/Player.tscn")

@onready var players_container: Node3D = $Players
@onready var hud: CanvasLayer = $HUD
@onready var lobby_camera: Camera3D = $LobbyCamera

# Spawn points for teams
const SPAWN_BLUE: Vector3 = Vector3(-14.0, 0.0, 0.0)
const SPAWN_RED: Vector3 = Vector3(14.0, 0.0, 0.0)

func _ready() -> void:
	NetworkManager.player_connected.connect(_on_player_connected)
	NetworkManager.player_disconnected.connect(_on_player_disconnected)
	NetworkManager.server_disconnected.connect(_on_server_disconnected)

	# Auto-start: Host if port available, or auto-join if already hosted!
	call_deferred("_auto_start_game")

func _auto_start_game() -> void:
	if multiplayer.multiplayer_peer == null:
		var err: Error = NetworkManager.host_game(7777)
		if err != OK:
			# Port 7777 is occupied by an existing Host instance, join it automatically
			NetworkManager.join_game("127.0.0.1", 7777)

func _on_player_connected(peer_id: int, player_info: Dictionary) -> void:
	# Disable overview lobby camera once local player spawns
	if lobby_camera and peer_id == multiplayer.get_unique_id():
		lobby_camera.current = false

	# Only server spawns replicated nodes
	if not multiplayer.is_server():
		return

	# Avoid duplicate spawning
	if players_container.has_node(str(peer_id)):
		return

	var player_instance: Player = player_scene.instantiate() as Player
	player_instance.name = str(peer_id)
	player_instance.peer_id = peer_id

	# Assign team and spawn point
	var team: int = player_info.get("team", 1 if peer_id == 1 else 2)
	player_instance.team = team
	player_instance.position = SPAWN_BLUE if team == 1 else SPAWN_RED

	players_container.add_child(player_instance, true)

func _on_player_disconnected(peer_id: int) -> void:
	if not multiplayer.is_server():
		return

	var player_node: Node = players_container.get_node_or_null(str(peer_id))
	if player_node:
		player_node.queue_free()

func _on_server_disconnected() -> void:
	for child in players_container.get_children():
		child.queue_free()
	if lobby_camera:
		lobby_camera.current = true
