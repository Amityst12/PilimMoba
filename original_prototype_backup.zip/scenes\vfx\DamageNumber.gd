extends Node3D

@onready var label: Label3D = $Label3D

func setup(text_value: String, color: Color = Color(1.0, 0.3, 0.3, 1.0), is_crit: bool = false) -> void:
	if not is_inside_tree():
		await ready

	if label:
		label.text = text_value
		label.modulate = color
		if is_crit:
			label.font_size = 36
			scale = Vector3(1.3, 1.3, 1.3)

	# Random horizontal scatter for multiple hits
	var scatter_x: float = randf_range(-0.5, 0.5)
	var scatter_z: float = randf_range(-0.5, 0.5)
	var target_pos: Vector3 = position + Vector3(scatter_x, 2.2, scatter_z)

	var tween: Tween = create_tween().set_parallel(true)
	# Float upward
	tween.tween_property(self, "position", target_pos, 0.85).set_trans(Tween.TRANS_OUT).set_ease(Tween.EASE_OUT)
	# Fade out near end
	tween.tween_property(label, "modulate:a", 0.0, 0.35).set_delay(0.5)
	# Clean up
	tween.chain().tween_callback(queue_free)
