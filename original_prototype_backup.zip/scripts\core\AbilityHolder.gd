class_name AbilityHolder
extends Node

signal cooldown_updated(slot: String, remaining: float, total: float)
signal ability_executed(slot: String, ability: Ability)
signal passive_updated(description: String, current_stacks: int, max_stacks: int, is_active: bool)

@export var passive: Ability
@export var ability_q: Ability
@export var ability_w: Ability
@export var ability_e: Ability
@export var ability_r: Ability

var cooldown_timers: Dictionary = {
	"Q": 0.0,
	"W": 0.0,
	"E": 0.0,
	"R": 0.0
}

@onready var player: CharacterBody3D = get_parent() as CharacterBody3D

func _ready() -> void:
	# Ensure default abilities are instantiated if not assigned in Inspector
	if not passive:
		passive = PassiveAbility.new()
	if not ability_q:
		ability_q = AbilityQ.new()
	if not ability_w:
		ability_w = AbilityW.new()
	if not ability_e:
		ability_e = AbilityE.new()
	if not ability_r:
		ability_r = AbilityR.new()

func _process(delta: float) -> void:
	# Update cooldown timers
	for slot: String in cooldown_timers.keys():
		if cooldown_timers[slot] > 0.0:
			cooldown_timers[slot] = max(0.0, cooldown_timers[slot] - delta)
			var ability: Ability = get_ability(slot)
			var total_cd: float = ability.cooldown if ability else 1.0
			cooldown_updated.emit(slot, cooldown_timers[slot], total_cd)

	# Update passive tick (healing, buff countdown)
	if passive and passive is PassiveAbility and player:
		(passive as PassiveAbility).update_passive(player, delta)

func get_ability(slot: String) -> Ability:
	match slot.to_upper():
		"PASSIVE":
			return passive
		"Q":
			return ability_q
		"W":
			return ability_w
		"E":
			return ability_e
		"R":
			return ability_r
	return null

func is_on_cooldown(slot: String) -> bool:
	return cooldown_timers.get(slot.to_upper(), 0.0) > 0.0

func start_cooldown(slot: String) -> void:
	var key: String = slot.to_upper()
	var ability: Ability = get_ability(key)
	if ability:
		cooldown_timers[key] = ability.cooldown
		cooldown_updated.emit(key, ability.cooldown, ability.cooldown)

func can_cast(slot: String) -> bool:
	var key: String = slot.to_upper()
	if is_on_cooldown(key):
		return false
	var ability: Ability = get_ability(key)
	if not ability:
		return false
	if not ability.can_cast(player):
		return false
	return true

# Server-side execution
func execute_cast(slot: String, target_pos: Vector3) -> bool:
	var key: String = slot.to_upper()
	if not can_cast(key):
		return false

	var ability: Ability = get_ability(key)
	if not ability:
		return false

	# Deduct mana if caster supports it
	if player.has_method("consume_mana"):
		player.consume_mana(ability.mana_cost)

	# Execute ability
	ability.execute(player, target_pos)
	start_cooldown(key)
	ability_executed.emit(key, ability)

	# Trigger passive hook
	if passive and passive is PassiveAbility:
		(passive as PassiveAbility).on_ability_cast(player, key)

	return true
